package com.example.studybuddy.utility;

public class userData {
    public static String userName;
    public static String userEmail;
    public static String userPassword;
    public static String userSchool;
    public static String userMajor;
    public static String userNickname;
    public static String profileUrl;

}
